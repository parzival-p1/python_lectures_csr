import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

class Invoice_item:
    count = 1

    def __init__(self, main_frame, dict_cars, owner, y):
        self.row_id = Invoice_item.count
        Invoice_item.count += 1
        self.main_frame = main_frame
        self.dict_cars = dict_cars
        self.width = main_frame.winfo_width() - 10
        self.height = main_frame.winfo_height() / 7
        self.owner = owner
        self.y = y

    def show_row(self):
        self.row_frame = tk.Frame(self.main_frame,  width=self.width, height=self.height, bg='#484b4c')
        self.txt_car_id = ttk.Combobox(self.row_frame, width=10, state="readonly",
                                         values=list(self.dict_cars.keys()))
        self.txt_car_id.place(x=5, y=5)

        self.txt_car_id.bind("<<ComboboxSelected>>", lambda event: self.update_fields(event))

        self.lbl_car_description = tk.Label(self.row_frame, bg='#484b4c', fg="white", text='')
        self.lbl_car_description.place(x=100, y=5)

        # Stock
        self.txt_car_stock = ttk.Combobox(self.row_frame, width=5, state="readonly")
        self.txt_car_stock.place(x=500, y=5)
        self.txt_car_stock.bind("<<ComboboxSelected>>", lambda event: self.update_totals(event))

        # Precio Unitario
        self.lbl_unit_price = tk.Label(self.row_frame, bg='#484b4c', fg="white", text='$')
        self.lbl_unit_price.place(x=550, y=5)

        # Delete
        self.btn_delete_concept = tk.Button(self.row_frame, text="Delete", width=5, command=self.delete_row)
        self.btn_delete_concept.place(x=650, y=5)
        self.row_frame.place(x=5, y=self.y)

    def update_totals(self, event):
        self.owner.update_totals()

    def update_fields(self, event):
        self.txt_car_stock.set('') # clean field
        car_id = self.txt_car_id.get()
        stock_list = [x for x in range (1, int(self.dict_cars[car_id][0]) + 1)]
        self.txt_car_stock['values'] = stock_list
        self.lbl_car_description.config(text=self.dict_cars[car_id][1])
        self.lbl_unit_price.config(text="$ " + self.dict_cars[car_id][2])

    def get_selected_data(self):
        if self.txt_car_id.get() == "":
            messagebox.showerror("Error!", "No se ha seleccionado un concepto")
        elif self.txt_car_stock.get() == "":
            messagebox.showerror("Error!", "No se ha seleccionado un cantidad")
        else:
            return self.txt_car_id.get(), self.txt_car_stock.get()
        return 0, 0

    def __eq__(self, other):
        return isinstance(other, Invoice_item) and self.txt_car_id.get() == other.txt_car_id.get()

    def __hash__(self):
        return hash(self.txt_car_id.get())

    def delete_row(self):
        self.owner.remove_item(self)
